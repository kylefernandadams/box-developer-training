const AWS = require('aws-sdk');

const moment = require('moment');
const BoxSDK = require('box-node-sdk');
const boxConfig = JSON.parse(process.env.BOX_CONFIG);
const sdk = BoxSDK.getPreconfiguredInstance(boxConfig);


class BoxManager {
    processBoxEnterpriseEvents() {
        return new Promise((resolve, reject) => {
            const client = sdk.getAppAuthClient('enterprise');
            const now = moment.utc(new Date()).format();
            console.log('Now: ', now);
            const startDate = moment(now).subtract(5, 'days').utc().format();
            console.log('Start date: ', startDate);
        
            const eventsJson = {
                events: []
            };
        
            const EVENT_TYPES = [
                client.events.enterpriseEventTypes.UPLOAD,
                client.events.enterpriseEventTypes.PREVIEW
            ];   
            client.events.getEnterpriseEventStream({
                startDate: startDate,
                pollingInterval: 0,
                eventTypeFilter: EVENT_TYPES
            })
            .then(stream => {
                stream.on('error', (err) => {
                    console.log('Found error streaming events:', err);
                });
                stream.on('data', event => {
                    console.log('Streaming events...');
                    console.log('Found event:', JSON.stringify(event, null, 2));
                    eventsJson.events.push(event);
                });
                stream.on('end', () => {
                    console.log('End of enterprise event stream');
                    const currentDateTime = moment().format('YYYY-MM-DD-hh-mm-ss');
                    // fs.writeFileSync(`/Developer/events/box-events-${currentDateTime}.json`, JSON.stringify(eventsJson, null, 2));
                    resolve('Done!!!');
                });
            })
            .catch(err => {
                console.log(err);
                reject(err);
            });
        });
        
    }
}
module.exports = new BoxManager();    